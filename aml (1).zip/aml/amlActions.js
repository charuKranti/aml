import {
  FETCH_AML_REQUEST,
  FETCH_AML_SUCCESS,
  FETCH_AML_FAILURE,
  FETCH_AML_DECISION_CHANGE,
} from "../constants/amlConstants";

export const amlRequest = (aml) => {
  return {
    type: FETCH_AML_REQUEST,
     aml: aml,
  };
};

export const amlSuccess = (aml) => {
  return {
    type: FETCH_AML_SUCCESS,
      aml: aml,
  };
};
export const amlFailure = (error) => {
  return {
    type: FETCH_AML_FAILURE,
    error: error,
  };
};

export const amlDecisionChange = (amlDecision) => {
  return {
    type: FETCH_AML_DECISION_CHANGE,
    amlDecision: amlDecision,
  };
};

