import {
  FETCH_AML_REQUEST,
  FETCH_AML_SUCCESS,
  FETCH_AML_FAILURE,
  FETCH_AML_DECISION_CHANGE,
  

} from "../constants/amlConstants";

const amlIntialState = {
  amlData: {},

amlTabData: {
    iDNRICVerified: false,
    premiumCheckAgainstBenefit: false,
    allSOXChecked: false,
    uwDValue: "",
    uwDecissionReason: "",
    amlDecision: {
      decision: "",
      suspendTill: null,
      suspendedPeriod: "",
      actedBt: "",
      remarks: "",
      pendDate: null,
      suspensionDate: null,
    },
    ntuReason: {
      reason: "",
      others: "",
    },

    initialDataForRefresh: {},
  },
}

export const amlReducer = (state = amlIntialState, action) => {
  switch (action.type) {
    case FETCH_AML_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case FETCH_AML_SUCCESS:
      console.log("reducer aml--", action);
      return {
        ...state,
        loading: false,
        amlData: action.aml,
        error: "",
      };
    case FETCH_AML_FAILURE:
      return {
        ...state,
        loading: false,
        data: [],
        error: action.error,
      };
      case FETCH_AML_DECISION_CHANGE:
      return {
        ...state,
        amlTabData:{
          ...state.amlTabData,
        amlDecision: action.amlDecision,
      },
    };
    default:
      return state;
  };
}
