import { Grid } from "@material-ui/core";
import React from "react";
import AccordionComponent from "../../../ReusableComponents/AccordionListComponent";
import FollowupForm from "../../../ReusableComponents/FollowUpCode";
import Decision from "./sections/Decision.jsx";
const AmlOpsPage = () => {
  const config = [
    {
      label: "Follow Up Code",
      component: <FollowupForm />,
    },
    { label: "Decision", component: <Decision /> },
  ];

  return (
    <Grid container spacing={1}>
      <AccordionComponent data={config} />
    </Grid>
  );
};

export default AmlOpsPage;
