import { Grid } from "@material-ui/core";
import React from "react";
import AccordionComponent from "../../../ReusableComponents/AccordionListComponent";
import FollowupForm from "../../../ReusableComponents/FollowUpCode";
//import PolicyDetailsHeaderActions from "../../../reusableComponents/PolicyDetailsHeaderActions.jsx";

import Decision from "./sections/Decision.jsx";
const AmlCompliancePage = () => {
  const config = [
    {
      label: "Follow Up Code",
      component: <FollowupForm />,
    },
    { label: "Decision", component: <Decision /> },
  ];

  return (
    <Grid container spacing={1}>
      <AccordionComponent data={config} />
    </Grid>
  );
};

export default AmlCompliancePage;
