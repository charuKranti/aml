import React, { useState } from "react";
import {
  Grid,
  FormControl,
  Radio,
  RadioGroup,
  FormControlLabel,
  TextareaAutosize,
} from "@material-ui/core";
import MenuItem from "@material-ui/core/MenuItem";
import Select from "@material-ui/core/Select";
import { connect, useDispatch } from "react-redux";
import DateFnsUtils from "@date-io/date-fns";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import InputLabel from "@material-ui/core/InputLabel";
import { uwCaseDecisionChange } from "../../../../../redux/actions/taskDetailsActions";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import TextFieldComponent from "../../../../ReusableComponents/TextField";
import { fetchAmlProposer } from "../../../../../services/api";
import { amlDecisionChange } from "../../../../../redux/actions/amlActions";
import * as utils from "../../../../../utils/utils";
import "../../aml.css";

const Decision = (props) => {
  const dispatch = useDispatch();
  React.useEffect(() => {
    dispatch(fetchAmlProposer(props?.location?.state?.amlData));
  }, []);
  const dateFns = new DateFnsUtils();
  const handleDecisionChange = (event) => {
    if (event.target.value === "Pend for requirement") {
      props.dispatch(
        amlDecisionChange({
          ...props.amlDecision,
          [event.target.name]: event.target.value,
          ntuDate: dateFns.addDays(new Date(), 30),
        })
      );
    } else if (event.target.value === "Park for later") {
      props.dispatch(
        amlDecisionChange({
          ...props.amlDecision,
          [event.target.name]: event.target.value,
          suspensionDate: dateFns.addDays(new Date(), 0),
        })
      );
    } else {
      props.dispatch(
        amlDecisionChange({
          ...props.caseDecision,
          [event.target.name]: event.target.value,
          pendDate: null,
        })
      );
    }
  };
  const handleSuspendDateChange = (key, val) => {
    const dateDiff = utils._getDaysDiff(new Date(), new Date(val));
    props.dispatch(
      uwCaseDecisionChange({
        ...props.caseDecision,
        [key]: val,
        suspendedPeriod: dateDiff,
      })
    );
  };
  const handleInputChange = () => {};
  const radioButtonData = [
    { name: "Pend for requirement", value: "Pend for requirement" },
    { name: "Approve", value: "Approve" },
    { name: "Park for later", value: "Park for later" },
    { name: "Reject", value: "Reject" },
    { name: "Transfer to Ops", value: "Transfer to Ops" },
    { name: "Transfer to NB", value: "Transfer to NB" },
  ];
  return (
    <Grid container className="row-throwback">
      {/* <pre>{JSON.stringify(props?.amlDecision, null, 2)}</pre>
      <pre>{JSON.stringify(props?.aml, null, 2)}</pre> */}
      <Grid container item sm={12} className="grid-container-fields">
        <Grid item className="custom-dropdown-container">
          <FormControl variant="outlined" className="uw_fromcontrol">
            <RadioGroup
              row
              aria-label="position"
              name="decision"
              value={props?.caseDecision?.decision}
              onChange={handleDecisionChange}
            >
              {radioButtonData.map((radioButton, i) => (
                <FormControlLabel
                  key={i}
                  value={radioButton.value}
                  control={<Radio color="primary" />}
                  label={<span className="FS14">{radioButton.name}</span>}
                  labelPlacement="end"
                  size="small"
                />
              ))}
            </RadioGroup>
          </FormControl>
        </Grid>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          {props.amlDecision?.decision &&
            props.amlDecision?.decision === "Park for later" && (
              <Grid item sm={3}>
                <KeyboardDatePicker
                  disableToolbar
                  variant="inline"
                  format="MM/dd/yyyy"
                  margin="normal"
                  label="Suspension Date"
                  value={props.amlDecision.suspensionDate}
                  // InputProps={{ disabled: true }}
                  disabled={true}
                  fullWidth
                  onChange={(date) =>
                    props.dispatch(
                      amlDecisionChange({
                        ...props.amlDecision,
                        suspensionDate: date,
                      })
                    )
                  }
                  KeyboardButtonProps={{
                    "aria-label": "change date",
                  }}
                  className="select-datepicker-g"
                  keyboardIcon={
                    <img
                      src="../../../assets/Icons/Calender.svg"
                      alt="calendar"
                      className="calanderIcon"
                    />
                  }
                />
              </Grid>
            )}
          {props.amlDecision.decision &&
            props.amlDecision.decision === "Pend for requirement" && (
              <Grid item sm={3}>
                <KeyboardDatePicker
                  disableToolbar
                  variant="inline"
                  format="MM/dd/yyyy"
                  margin="normal"
                  label="NTU Date"
                  value={props.amlDecision.ntuDate}
                  // InputProps={{ disabled: true }}
                  disabled={true}
                  fullWidth
                  onChange={(date) =>
                    props.dispatch(
                      amlDecisionChange({
                        ...props.ntuCaseDecision,
                        ntuDate: date,
                      })
                    )
                  }
                  KeyboardButtonProps={{
                    "aria-label": "change date",
                  }}
                  className="select-datepicker-g"
                  keyboardIcon={
                    <img
                      src="../../../assets/Icons/Calender.svg"
                      alt="calendar"
                      className="calanderIcon"
                    />
                  }
                />
              </Grid>
            )}
          <Grid item sm={12}>
            <TextFieldComponent
              className="field-textarea-g"
              aria-label="minimum height"
              rows={3}
              rowsMax={5}
              label="Comments"
              multiline
              name="uwcomment"
              // value={uwCommentValue}
              onChange={handleInputChange}
            />
          </Grid>
        </MuiPickersUtilsProvider>
      </Grid>
    </Grid>
  );
};
const mapStateToProps = (state) => ({
  amlDecision: state.amlReducer?.amlTabData?.amlDecision,
  aml: state.amlReducer?.amlData?.aml,
});
export default connect(mapStateToProps)(Decision);
