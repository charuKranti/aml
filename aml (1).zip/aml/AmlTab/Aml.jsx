import React, { useState } from "react";
import TabComponent from "../../ReusableComponents/TabComponent";
import AmlCompliance from "./AmlCompliance/AmlCompliancePage";
import AmlOps from "./AmlOps/AmlOpsPage";

const tabLabels = [
  { label: "AML Compliance", component: <AmlCompliance /> },
  { label: "AML Ops", component: <AmlOps /> },
];

const Aml = () => {
  
  return (
    <TabComponent typeOfTab={'secondary'} tabLabels={tabLabels}/>
  );
};

export default Aml;
