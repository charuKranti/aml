import { Grid } from "@material-ui/core";
import React from "react";
import AccordionListComponent from "../../ReusableComponents/AccordionListComponent";
import PrushieldPremiumProjection from "./sections/PrushieldPremiumProjection.jsx";
import Deduction from "./sections/CpfDeduction.jsx";
import ManualDeduction from "./sections/CpfManualDeducation";
import Decision from "./sections/CpfDecision";
const ShieldCPF = () => {
  const config = [
    {
      label: "PruShield - Premium Projection and other details",
      component: <PrushieldPremiumProjection />,
    },
    { label: "Deduction", component: <Deduction /> },
    { label: "Manual Deduction", component: <ManualDeduction /> },
    { label: "Case Decision", component: <Decision /> },
  ];

  return (
    <Grid container spacing={1}>
      <AccordionListComponent data={config} />
    </Grid>
  );
};

export default ShieldCPF;
