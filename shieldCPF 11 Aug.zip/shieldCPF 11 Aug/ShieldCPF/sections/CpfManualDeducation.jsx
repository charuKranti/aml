import React, { useState } from "react";
import Grid from "@material-ui/core/Grid";
import FormControl from "@material-ui/core/FormControl";
import DateFnsUtils from "@date-io/date-fns";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import DropdownComponent from '../../../ReusableComponents/Dropdown';
import TextFieldComponent from "../../../ReusableComponents/TextField";
import "./shieldCpf.css";
const ManualDeduction = () => {
  const manualDeductionObj = {
    transactionType: "",
    startRenewalDate: new Date(Date.now()),
    fixDate: "",
    deductFromMidSaveIPMI: "290.00",
    refundToMidSaveIMSH: "210.00",
    refundToMidSaveIPMI: "320.00",
    deductFromMidSaveIMSH: "210.00",
    endDate: new Date(Date.now()),
    reasonCode: "123",
    interest: "5%",
    approve: "",
  };
  const [state, setState] = useState(manualDeductionObj);
  const transaction = [{ name: "Adjustment", value: "1" }, { name: "Cancellation", value: "2" }, { name: "Change Payor", value: "3" }, { name: "Furt Deduc", value: "4" }, { name: "New Cover", value: "5" }, { name: "Renew/Revive", value: "6" }, { name: "Revival-ML", value: "7" }, { name: "Termination", value: "8" }];
  const handleChange = (event) => {
    setState({ ...state, transactionType: event.target.value });
    console.log("decision");
    console.log(state);
  };
  const handleStartDateChange = (date) => {
    setState({ ...state, startRenewalDate: date });
  };
  const handleEndDateChange = (date) => {
    setState({ ...state, endDate: date });
  };
  const handleFixDate = (event) => {
    setState({ ...state, [event.target.name]: event.target.value });
  };
  const handleTextFieldChange = (event) => {
    console.log(event);
    setState({ ...state, [event.target.name]: event.target.value });
  };
  return (
    <Grid container spacing={2} direction="column">
      <Grid container item sm={12} spacing={1}>
        <Grid item sm={3} className="custom-dropdown-container">
          <DropdownComponent MenuProps={{ className: "mui-select-dropdown-container" }} className="custom-dropdown-element" label="Transaction Type" value={state.transactionType} name="selectCode" onChange={handleChange} options={transaction} />
        </Grid>
        <Grid item sm={3}>
          <MuiPickersUtilsProvider utils={DateFnsUtils}>
            <Grid
              container
              justify="flex-start"
              className="cpf-deduction-datepicker"
            >
              <KeyboardDatePicker
                className="select-datepicker-g"
                disableToolbar
                variant="inline"
                format="MM/dd/yyyy"
                margin="normal"
                id="date-picker-inline"
                label="start Renewal Date"
                name="startRenewalDate"
                value={state.startRenewalDate}
                onChange={handleStartDateChange}
                KeyboardButtonProps={{
                  "aria-label": "change date",
                }}
                InputProps={{ disableUnderline: true }}
                keyboardIcon={
                  <img
                    src="../../../assets/Icons/Calender.svg"
                    alt="calendar"
                    className="calanderIcon"
                  />
                }
              />
            </Grid>
          </MuiPickersUtilsProvider>
        </Grid>
        <Grid item sm={6}>
          <FormControl component="fieldset" className="fix-date-fieldset">
            <FormLabel className="fixDateLabel">Fix Date</FormLabel>
            <RadioGroup
              row
              aria-label="Add-to-Concurrent-Policies"
              name="fixDate"
              value={state.fixDate}
              onChange={handleFixDate}
            >
              <FormControlLabel
                className="radio-button-label"
                value="yes"
                control={<Radio />}
                label={<span className="FS14">Yes</span>}
                labelPlacement="end"
                size="small"
              />
              <FormControlLabel
                className="radio-button-label"
                value="no"
                control={<Radio />}
                label={<span className="FS14">No</span>}
                labelPlacement="end"
                size="small"
              />
            </RadioGroup>
          </FormControl>
        </Grid>
        <Grid item sm={3}>
          <TextFieldComponent
            className="field-text-g"
            id="deductFromMidSaveIPMI"
            name="deductFromMidSaveIPMI"
            value={state.deductFromMidSaveIPMI}
            label="Deduct From Medisave(IPMI)"
            onChange={handleTextFieldChange}
            InputProps={{ disableUnderline: true }}
            fullWidth
          />
        </Grid>
        <Grid item sm={3}>
          <TextFieldComponent
            className="field-text-g"
            id="refundToMidSaveIMSH"
            name="refundToMidSaveIMSH"
            value={state.refundToMidSaveIMSH}
            label="Refund To Medisave(IMSH)"
            onChange={handleTextFieldChange}
            InputProps={{ disableUnderline: true }}
            fullWidth
          />
        </Grid>
        <Grid item sm={3}>
          <TextFieldComponent
            className="field-text-g"
            id="refundToMidSaveIPMI"
            name="refundToMidSaveIPMI"
            value={state.refundToMidSaveIPMI}
            label="Refund To Medisave(IPMI)"
            onChange={handleTextFieldChange}
            InputProps={{ disableUnderline: true }}
            fullWidth
          />
        </Grid>
        <Grid item sm={3}>
          <TextFieldComponent
            className="field-text-g"
            id="deductFromMidSaveIMSH"
            name="deductFromMidSaveIMSH"
            value={state.deductFromMidSaveIMSH}
            label="Deduct From Medisave(IMSH)"
            onChange={handleTextFieldChange}
            InputProps={{ disableUnderline: true }}
            fullWidth
          />
        </Grid>
        <Grid item sm={3}>
          <MuiPickersUtilsProvider utils={DateFnsUtils}>
            <Grid
              container
              justify="flex-start"
              className="cpf-deduction-datepicker"
            >
              <KeyboardDatePicker
                className="select-datepicker-g"
                disableToolbar
                variant="inline"
                format="MM/dd/yyyy"
                margin="normal"
                id="date-picker-inline"
                label="End Date"
                value={state.endDate}
                name="endDate"
                onChange={handleEndDateChange}
                KeyboardButtonProps={{
                  "aria-label": "change date",
                }}
                InputProps={{ disableUnderline: true }}
                keyboardIcon={
                  <img
                    src="../../../assets/Icons/Calender.svg"
                    alt="calendar"
                    className="calanderIcon"
                  />
                }
              />
            </Grid>
          </MuiPickersUtilsProvider>
        </Grid>
        <Grid item sm={3}>
          <TextFieldComponent
            className="field-text-g"
            id="reasonCode"
            name="reasonCode"
            value={state.reasonCode}
            label="Reason Code"
            onChange={handleTextFieldChange}
            InputProps={{ disableUnderline: true }}
            fullWidth
          />
        </Grid>
        <Grid item sm={3}>
          <TextFieldComponent
            className="field-text-g"
            id="interest"
            name="interest"
            value={state.interest}
            label="Interest"
            onChange={handleTextFieldChange}
            InputProps={{ disableUnderline: true }}
            fullWidth
          />
        </Grid>
        {/* <Grid item sm={6}>
          <FormControl component="fieldset" className="fix-date-fieldset">
            <FormLabel className="fixDateLabel">Approve</FormLabel>
            <RadioGroup
              row
              aria-label="Add-to-Concurrent-Policies"
              name="approve"
              value={state.approve}
              onChange={handleFixDate}
            >
              <FormControlLabel
                className="radio-button-label"
                value="approveyes"
                control={<Radio />}
                label={<span className="FS14">Yes</span>}
                labelPlacement="end"
                size="small"
              />
              <FormControlLabel
                className="radio-button-label"
                value="approveno"
                control={<Radio />}
                label={<span className="FS14">No</span>}
                labelPlacement="end"
                size="small"
              />
            </RadioGroup>
          </FormControl>
        </Grid> */}
      </Grid>
    </Grid>
  );
};

export default ManualDeduction;
