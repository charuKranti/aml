import React from "react";
import { Grid } from "@material-ui/core";
import MaterialTable from "material-table";
import { connect, useDispatch } from "react-redux";
import DateFnsUtils from "@date-io/date-fns";
import "./shieldCpf.css";
const Deduction = (props) => {
  const dateFns = new DateFnsUtils();

  return (
    <Grid container>
      <Grid item xs={12} className="selection-view table-default-view">
        <MaterialTable
          title=""
          columns={[
            {
              title: "Request Date",
              render: (rowData) => (
                <span>
                  {dateFns.isValid(rowData.requestDate)
                    ? dateFns.format(
                        new Date(rowData.requestDate),
                        "dd/MM/yyyy"
                      )
                    : rowData.requestDate}
                </span>
              ),
              field: "requestDate",
              sorting: false,
            },
            {
              title: "Extraction Date",
              render: (rowData) => (
                <span>
                  {dateFns.isValid(rowData.extractionDate)
                    ? dateFns.format(
                        new Date(rowData.extractionDate),
                        "dd/MM/yyyy"
                      )
                    : rowData.extractionDate}
                </span>
              ),
              field: "extractionDate",
              sorting: false,
            },
            {
              title: "Return Date",
              render: (rowData) => (
                <span>
                  {dateFns.isValid(rowData.returnDate)
                    ? dateFns.format(new Date(rowData.returnDate), "dd/MM/yyyy")
                    : rowData.returnDate}
                </span>
              ),
              field: "returnDate",
              sorting: false,
            },
            { title: "Status", field: "status", sorting: false },
            { title: "Approver", field: "approver", sorting: false },
            { title: "Manual", field: "manual", sorting: false },
          ]}
          data={props.deduction}
          options={{
            actionsColumnIndex: -1,
            search: false,
            exportButton: true,
            grouping: false,
            filtering: false,
            paging: false,
            sorting: true,
            draggable: false,
            maxBodyHeight: "400px",
            toolbar: false,
            showTextRowsSelected: false,
            rowStyle: {
              height: 40,
            },
            headerStyle: {
              whiteSpace: "nowrap",
              backgroundColor: "#8d9aac",
              color: "#ffffff",
              height: 40,
            },
          }}
          detailPanel={[
            {
              tooltip: "Show Name",
              render: (rowData) => {
                return (
                  <Grid
                    container
                    style={{
                      fontSize: 13,
                      textAlign: "justify",
                      color: "#000000",
                      backgroundColor: "#EEF0F1",
                      marginTop: "-1px",
                      fontFamily: "Open Sans,Regular",
                      marginLeft: "-6px",
                      marginRight: "-6px",
                    }}
                  >
                    <Grid item xs={3}>
                      <label className="extTextLabel">
                        Medishield Life Cash Amount
                      </label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.medishieldLifeCashAmount
                        }
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">
                        Medishield Life Premium
                      </label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.medishieldLifePremium
                        }
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">
                        Integrated PruShield Medical Amount
                      </label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.integratedPrushieldMedicalAmount
                        }
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">
                        Medisheld Life Premium (Nett)
                      </label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.medishieldLifePremiumNett
                        }
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">Blocked Amount</label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.blockedAmount
                        }
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">
                        Total MS Deduction/Refund
                      </label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.totalMsDeductionRefund
                        }
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">MSHL- Rebate</label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.mshlRebate
                        }
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">
                        MSHL- Pioneer Generation/Merdeka Subsity
                      </label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.mshlPioneerGenerationMerdekaSubsidy
                        }
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">
                        MSHL- Additional Premium
                      </label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.mshlAdditionalPremium
                        }
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">
                        KSHL- Transitional Subsity
                      </label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.mshlTransitionalSubsidy
                        }
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">MSHL- Medial</label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.mshlMedical
                        }
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">MSHL- GST</label>
                      <p className="extTextData">
                        {rowData.shieldDeductionMedishieldLifeDetails?.mshlGst}
                      </p>
                    </Grid>
                    <Grid item xs={3}>
                      <label className="extTextLabel">Rejection Reason</label>
                      <p className="extTextData">
                        {
                          rowData.shieldDeductionMedishieldLifeDetails
                            ?.rejectionReason
                        }
                      </p>
                    </Grid>
                  </Grid>
                );
              },
            },
          ]}
        />
      </Grid>
    </Grid>
  );
};
const mapStateToProps = (state) => ({
  deduction: state.sheildCpfReducer?.shieldCpfData?.shieldDeductionDetails,
});

export default connect(mapStateToProps)(Deduction);
