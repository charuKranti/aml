import React, { useState } from "react";
import {
  Grid,
  FormControl,
  RadioGroup,
  Radio,
  FormControlLabel,
} from "@material-ui/core";
import DateFnsUtils from "@date-io/date-fns";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import { connect, useDispatch } from "react-redux";
import { shieldCpfDecisionChange } from "../../../../redux/actions/shieldCpfNbActions";

import "./shieldCpf.css";
const Decision = (props) => {
  const radioButtonInputs = [
    { name: "Transfer for Approver", value: "Transfer for Approver" },
    { name: "Approve", value: "Y" },
    { name: "Reject", value: "N" },
    { name: "Complete", value: "Complete" },
    { name: "Pend for requirement", value: "Pend for requirement" },
    { name: "Park for later", value: "Park for later" },
  ];

  const dateFns = new DateFnsUtils();
  const handleDecisionChange = (event) => {
    if (event.target.value === "Pend for requirement") {
      props.dispatch(
        shieldCpfDecisionChange({
          ...props.caseDecision,
          [event.target.name]: event.target.value,
          pendDate: dateFns.addDays(new Date(), 30),
        })
      );
    } else if (event.target.value === "Park for later") {
      props.dispatch(
        shieldCpfDecisionChange({
          ...props.caseDecision,
          [event.target.name]: event.target.value,
          suspensionDate: dateFns.addDays(new Date(), 14),
        })
      );
    } else {
      props.dispatch(
        shieldCpfDecisionChange({
          ...props.caseDecision,
          [event.target.name]: event.target.value,
          pendDate: null,
        })
      );
    }
  };
  return (
    <Grid container>
      <Grid xs={12}>
        <pre>{JSON.stringify(props?.caseDecision, null, 2)}</pre>
      </Grid>
      <Grid item xs={8} direction="row">
        <FormControl component="fieldset">
          <RadioGroup
            row
            aria-label="position"
            name="decision"
            //value={props?.ntuReason?.reason}
            onChange={handleDecisionChange}
          >
            {radioButtonInputs.map((radioButton, i) => (
              <FormControlLabel
                key={i}
                value={radioButton.value}
                control={<Radio color="primary" />}
                label={<span className="FS14">{radioButton.name}</span>}
                labelPlacement="end"
                size="small"
              />
            ))}
          </RadioGroup>
        </FormControl>
      </Grid>

      <MuiPickersUtilsProvider utils={DateFnsUtils}>
        {props.caseDecision.decision &&
          props.caseDecision.decision === "Park for later" && (
            <Grid item sm={3}>
              <KeyboardDatePicker
                disableToolbar
                variant="inline"
                format="MM/dd/yyyy"
                margin="normal"
                label="Suspension Date"
                value={props.caseDecision.suspensionDate}
                // InputProps={{ disabled: true }}
                disabled={true}
                fullWidth
                onChange={(date) =>
                  props.dispatch(
                    shieldCpfDecisionChange({
                      ...props.caseDecision,
                      suspensionDate: date,
                    })
                  )
                }
                KeyboardButtonProps={{
                  "aria-label": "change date",
                }}
                className="select-datepicker-g"
                keyboardIcon={
                  <img
                    src="../../../assets/Icons/Calender.svg"
                    alt="calendar"
                    className="calanderIcon"
                  />
                }
              />
            </Grid>
          )}
        {props.caseDecision.decision &&
          props.caseDecision.decision === "Pend for requirement" && (
            <Grid item sm={3}>
              <KeyboardDatePicker
                disableToolbar
                variant="inline"
                format="MM/dd/yyyy"
                margin="normal"
                label="Pend Date"
                value={props.caseDecision.pendDate}
                // InputProps={{ disabled: true }}
                disabled={true}
                fullWidth
                onChange={(date) =>
                  props.dispatch(
                    shieldCpfDecisionChange({
                      ...props.caseDecision,
                      pendDate: date,
                    })
                  )
                }
                KeyboardButtonProps={{
                  "aria-label": "change date",
                }}
                className="select-datepicker-g"
                keyboardIcon={
                  <img
                    src="../../../assets/Icons/Calender.svg"
                    alt="calendar"
                    className="calanderIcon"
                  />
                }
              />
            </Grid>
          )}
      </MuiPickersUtilsProvider>
    </Grid>
  );
};

const mapStateToProps = (state) => ({
  caseDecision: state.sheildCpfReducer?.sheldCpfTabData?.caseDecision,
  //ntu: state.ntuNbReducer?.ntuReopenData?.ntuReopen,
});

export default connect(mapStateToProps)(Decision);
