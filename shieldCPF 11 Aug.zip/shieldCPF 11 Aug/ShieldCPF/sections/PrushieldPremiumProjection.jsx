import React, { useState } from "react";
import { Grid, Divider, Button } from "@material-ui/core";
import ProjectionDetails from "./ProjectionDetails";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { connect, useDispatch } from "react-redux";
import ReadOnlyTextfieldList from "../../../ReusableComponents/ReadOnlyTextfieldList";
import TextFieldComponent from "../../../ReusableComponents/TextField";
import { fetchShieldCpfProposer } from "../../../../services/api";
import DateFnsUtils from "@date-io/date-fns";
import "./shieldCpf.css";
const PrushieldPremiumProjection = (props) => {
  const dateFns = new DateFnsUtils();
  const dispatch = useDispatch();
  React.useEffect(() => {
    dispatch(fetchShieldCpfProposer(props?.location?.state?.shield));
  }, []);

  const premiumProjection = {
    fixDate: "",
    supressLetter: "",
  };
  const inputData = [
    {
      label: "Client Number",
      value: props.shield?.shieldPremiumProjection?.clientNumberOwner,
    },
    {
      label: "Owner Name",
      value: props.shield?.shieldPremiumProjection?.ownerName,
    },
    {
      label: "Owner NRIC",
      value: props.shield?.shieldPremiumProjection?.ownerNric,
    },
    {
      label: "Owner Nationality",
      value: props.shield?.shieldPremiumProjection?.ownerNationality,
    },
    {
      label: "Client Number",
      value: props.shield?.shieldPremiumProjection?.clientNumberPayor,
    },
    {
      label: "Payer Name",
      value: props.shield?.shieldPremiumProjection?.payorName,
    },
    {
      label: "Payer NRIC",
      value: props.shield?.shieldPremiumProjection?.payorNric,
    },
    {
      label: "Payer Nationality",
      value: props.shield?.shieldPremiumProjection?.payorNationality,
    },
    {
      label: "Client Number",
      value: props.shield?.shieldPremiumProjection?.clientNumberLifeAssured,
    },
    {
      label: "Life Assured Name",
      value: props.shield?.shieldPremiumProjection?.lifeAssuredName,
    },
    {
      label: "Life Assured NRIC",
      value: props.shield?.shieldPremiumProjection?.lifeAssuredNric,
    },
    {
      label: "Life Assured Nationality",
      value: props.shield?.shieldPremiumProjection?.lifeAssuredNationality,
    },
    {
      label: "Child Medisave",
      value: props.shield?.shieldPremiumProjection?.childMedisave,
    },
    {
      label: "Owner CPF Account Number",
      value: props.shield?.shieldPremiumProjection?.ownerCpfAccountNumber,
    },
    {
      label: "Child CPF Account Number",
      value: props.shield?.shieldPremiumProjection?.childCpfAccountNumber,
    },
    {
      label: "Payer CPF Account Number",
      value: props.shield?.shieldPremiumProjection?.payorCpfAccountNumber,
    },
    {
      label: "Inception Date",
      value: new Date(props.shield?.shieldPremiumProjection?.inceptionDate),
    },
    {
      label: "Plan Component",
      value: props.shield?.shieldPremiumProjection?.planComponent,
    },
  ];
  const [state, setState] = useState(premiumProjection);
  const handleFixDate = (event) => {
    setState({ ...state, [event.target.name]: event.target.value });
  };
  return (
    <Grid className="row-throwback">
      <Grid container item className="grid-container-fields">
        <ReadOnlyTextfieldList sm={3} textFieldConfig={inputData} />
        <Grid item xs={12} className="selection-view table-default-view">
          <Divider className="divider" />
        </Grid>
        <Grid item xs={12} className="selection-view table-default-view">
          <div className="projectionTitle">Projection Details</div>
          <ProjectionDetails />
          <div className="retriggerPremium"> Retrigger Premium Projection</div>
        </Grid>
        <Grid item sm={3}>
          <TextFieldComponent
            disabled
            className="field-text-g prushieldPremiumProjectionInput"
            name="deductFromMidSaveIPMI"
            value={
              new Date(props.shield?.shieldPremiumProjection?.inceptionDate)
            }
            label="Inception Date"
          />
        </Grid>
        <Grid item sm={2}>
          <FormControl component="fieldset" className="fix-date-fieldset">
            <FormLabel className="fixDateLabel">Fix Date</FormLabel>
            <RadioGroup
              row
              aria-label="Add-to-Concurrent-Policies"
              name="fixDate"
              value={state.fixDate}
              onChange={handleFixDate}
            >
              <FormControlLabel
                className="radio-button-label"
                value="yes"
                control={<Radio />}
                label={<span className="FS14">Yes</span>}
                labelPlacement="end"
                size="small"
              />
              <FormControlLabel
                className="radio-button-label"
                value="no"
                control={<Radio />}
                label={<span className="FS14">No</span>}
                labelPlacement="end"
                size="small"
              />
            </RadioGroup>
          </FormControl>
        </Grid>
        <Grid item sm={2}>
          <FormControl component="fieldset" className="fix-date-fieldset">
            <FormLabel className="fixDateLabel">Supress Letter</FormLabel>
            <RadioGroup
              row
              aria-label="Add-to-Concurrent-Policies"
              name="supressLetter"
              value={state.supressLetter}
              onChange={handleFixDate}
            >
              <FormControlLabel
                className="radio-button-label"
                value="supressyes"
                control={<Radio />}
                label={<span className="FS14">Yes</span>}
                labelPlacement="end"
                size="small"
              />
              <FormControlLabel
                className="radio-button-label"
                value="supressno"
                control={<Radio />}
                label={<span className="FS14">No</span>}
                labelPlacement="end"
                size="small"
              />
            </RadioGroup>
          </FormControl>
        </Grid>
        <Grid item sm={3}>
          <Button className="btn-primary-blue-g retriggerButton">
            Retrigger Premium Projection
          </Button>
        </Grid>
      </Grid>
    </Grid>
  );
};

const mapStateToProps = (state) => ({
  shield: state.sheildCpfReducer?.shieldCpfData,
});
export default connect(mapStateToProps)(PrushieldPremiumProjection);
