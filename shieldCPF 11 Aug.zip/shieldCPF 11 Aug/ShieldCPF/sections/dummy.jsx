import React, { useState } from "react";
import Grid from "@material-ui/core/Grid";
import DateFnsUtils from "@date-io/date-fns";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import RadioButtonGroup from "../../../ReusableComponents/RadioButtonGroup";
import "./shieldCpf.css";
const Decision = () => {
  //cpf Decision object.
  const cpfDecision = {
    cpfRadioDecision: "",
    ntuDate: new Date(Date.now()),
    suspensionDate: new Date(Date.now()),
  };
  const [state, setState] = useState(cpfDecision);
  //For setting radio button input
  const radioButtonInputs = [
    { label: "Transfer for Approver", value: "transferForApprover" },
    { label: "Approve", value: "approve" },
    { label: "Reject", value: "reject" },
    { label: "Complete", value: "complete" },
    { label: "Pend For Req", value: "pendForReq" },
    { label: "Park for later", value: "parkForLater" },
  ];
  //For Setting date label
  const dateInputs = [
    { label: "NTU Date", value: "ntuDate" },
    { label: "Suspension Date", value: "suspensionDate" },
  ];
  /**
   * For setting radio button value.
   * @param {*} event
   */
  const handleChange = (val) => {
    setState({ ...state, cpfRadioDecision: val });
  };
  return (
    <Grid container>
      <Grid item sm={12}>
        <RadioButtonGroup
          selectedValue={state.cpfRadioDecision}
          handleChange={handleChange}
          data={radioButtonInputs}
        />
      </Grid>
      <Grid item sm={12}>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <Grid
            container
            justify="flex-start"
            className="cpf-decision-datepicker"
          >
            {dateInputs.map((datePicker, i) => (
              <KeyboardDatePicker
                className="select-datepicker-g"
                disableToolbar
                key={`date-picker-${i}`}
                variant="inline"
                format="MM/dd/yyyy"
                margin="normal"
                id={`date-picker-${i}`}
                label={datePicker.label}
                value={state[datePicker.value]}
                onChange={(date) =>
                  setState({ ...state, [datePicker.value]: date })
                }
                KeyboardButtonProps={{
                  "aria-label": "change date",
                }}
                keyboardIcon={
                  <img
                    src="../../../assets/Icons/Calender.svg"
                    alt="calendar"
                    className="calanderIcon"
                  />
                }
              />
            ))}
          </Grid>
        </MuiPickersUtilsProvider>
      </Grid>
    </Grid>
  );
};

export default Decision;
