import React from "react";
import { Grid } from "@material-ui/core";
import MaterialTable from "material-table";

import { makeStyles } from "@material-ui/core";
import { connect, useDispatch } from "react-redux";
import { fetchShieldCpfProposer } from "../../../../services/api";
import DateFnsUtils from "@date-io/date-fns";
import "./shieldCpf.css";
const useStyles = makeStyles((theme) => ({
  lightTooltip: {
    background: "#ffffff",
    color: "#000",
    fontSize: 11,
    width: "220px",
    padding: "5% 0% 5% 10%",
  },
}));
const ProjectionDetails = (props) => {
  const dateFns = new DateFnsUtils();
  const classes = useStyles();
  const dispatch = useDispatch();
  React.useEffect(() => {
    dispatch(fetchShieldCpfProposer(props?.location?.state?.shield));
  }, []);

  return (
    <Grid xs={12}>
      <MaterialTable
        title=""
        columns={[
          {
            title: "Request Date",
            render: (rowData) => (
              <span>
                {dateFns.isValid(rowData.requestDate)
                  ? dateFns.format(new Date(rowData.requestDate), "dd/MM/yyyy")
                  : rowData.requestDate}
              </span>
            ),
            field: "requestDate",
            sorting: false,
          },
          {
            title: "Extraction Date",
            render: (rowData) => (
              <span>
                {dateFns.isValid(rowData.extractionDate)
                  ? dateFns.format(
                      new Date(rowData.extractionDate),
                      "dd/MM/yyyy"
                    )
                  : rowData.extractionDate}
              </span>
            ),
            field: "extractionDate",
            sorting: false,
          },
          {
            title: "Return Date",
            render: (rowData) => (
              <span>
                {dateFns.isValid(rowData.returnDate)
                  ? dateFns.format(new Date(rowData.returnDate), "dd/MM/yyyy")
                  : rowData.returnDate}
              </span>
            ),
            field: "returnDate",
            sorting: false,
          },
          { title: "Status", field: "status", sorting: false },
          { title: "Requestor", field: "requestor", sorting: false },
          { title: "Manual", field: "manual", sorting: false },
          { title: "Remark", field: "remark", sorting: false },
        ]}
        data={props.shield}
        options={{
          actionsColumnIndex: -1,
          search: false,
          exportButton: true,
          grouping: false,
          filtering: false,
          paging: false,
          sorting: true,
          draggable: false,
          maxBodyHeight: "200px",
          toolbar: false,
          showTextRowsSelected: false,
          rowStyle: {
            height: 40,
          },

          headerStyle: {
            whiteSpace: "nowrap",
            backgroundColor: "#8d9aac",
            color: "#ffffff",
            height: 40,
          },
        }}
        detailPanel={[
          {
            render: (rowData) => {
              return (
                <Grid
                  container
                  style={{
                    fontSize: 13,
                    color: "#000000",
                    backgroundColor: "#EEF0F1",
                    paddingLeft: "30px",
                    fontFamily: "Open Sans,Regular",
                    marginLeft: "-10px",
                    marginRight: "-10px",
                    paddingBottom: "1px",
                  }}
                >
                  <Grid item xs={3}>
                    <label className="extTextLabel">
                      Medishield Life Premium
                    </label>
                    <p className="extTextData">
                      {rowData.medishieldLifeDetails?.medishieldLifePremium}
                    </p>
                  </Grid>
                  <Grid item xs={3}>
                    <label className="extTextLabel">
                      Medishield Life Subsidy Amount
                    </label>
                    <p className="extTextData">
                      {rowData.medishieldLifeDetails?.medishieldLifeSubsidyAmt}
                    </p>
                  </Grid>
                  <Grid item xs={3}>
                    <label className="extTextLabel">
                      Medishield Life Premium(Nett)
                    </label>
                    <p className="extTextData">
                      {rowData.medishieldLifeDetails?.medishieldLifePremiumNett}
                    </p>
                  </Grid>
                </Grid>
              );
            },
          },
        ]}
      />
    </Grid>
  );
};

const mapStateToProps = (state) => ({
  shield: state.sheildCpfReducer?.shieldCpfData?.shieldProjectionDetails,
});

export default connect(mapStateToProps)(ProjectionDetails);
