import {
  FETCH_SHIELDCPF_REQUEST,
  FETCH_SHIELDCPF_SUCCESS,
  FETCH_SHIELDCPF_FAILURE,
  FETCH_SHIELDCPF_DECISSION_CHANGE,
} from "../constants/shieldCpfNbConstants";

const cpfIntialState = {
  shieldCpfData: {},
  sheldCpfTabData: {
    caseDecision: {
      decision: "",
      suspendTill: null,
      suspendedPeriod: "",
      actedBt: "",
      remarks: "",
      pendDate: null,
      suspensionDate: null,
    },
  },
};

export const sheildCpfReducer = (state = cpfIntialState, action) => {
  switch (action.type) {
    case FETCH_SHIELDCPF_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case FETCH_SHIELDCPF_SUCCESS:
      console.log("reducer shield--", action);
      return {
        ...state,
        loading: false,
        shieldCpfData: action.shield,
        error: "",
      };
    case FETCH_SHIELDCPF_FAILURE:
      return {
        ...state,
        loading: false,
        data: [],
        error: action.error,
      };
    case FETCH_SHIELDCPF_DECISSION_CHANGE:
      return {
        ...state,
        sheldCpfTabData: {
          ...state.sheldCpfTabData,
          caseDecision: action.payload,
        },
      };
    default:
      return state;
  }
};
