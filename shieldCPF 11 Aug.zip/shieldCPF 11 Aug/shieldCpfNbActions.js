import {
  FETCH_SHIELDCPF_REQUEST,
  FETCH_SHIELDCPF_SUCCESS,
  FETCH_SHIELDCPF_FAILURE,
  FETCH_SHIELDCPF_DECISSION_CHANGE,
} from "../constants/shieldCpfNbConstants";

export const sheildCpfRequest = (shield) => {
  return {
    type: FETCH_SHIELDCPF_REQUEST,
    shield: shield,
  };
};

export const sheildCpfSuccess = (shield) => {
  return {
    type: FETCH_SHIELDCPF_SUCCESS,
    shield: shield,
  };
};
export const sheildCpfFailure = (error) => {
  return {
    type: FETCH_SHIELDCPF_FAILURE,
    error: error,
  };
};
export const shieldCpfDecisionChange = (res) => {
  return {
    type: FETCH_SHIELDCPF_DECISSION_CHANGE,
    payload: res,
  };
};
